//declare structure
struct PlayerNode
{
    int code, age;
    char name[50];
    char club[50];
    struct PlayerNode *nextNode;
};
#define PlayerNode struct PlayerNode
//set void methods
void addPlayer(PlayerNode **head);
PlayerNode *searchPlayer(PlayerNode *head, int code);
void updatePlayer(PlayerNode *head, int code);
void printPlayers(PlayerNode *head);
void deletePlayer(PlayerNode **head, int code);
void printPlayer(PlayerNode *head);