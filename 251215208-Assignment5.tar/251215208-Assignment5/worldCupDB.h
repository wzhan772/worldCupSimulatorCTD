struct PlayerNode *playerTeam = NULL;
struct TeamNode *headTeam = NULL;
void teamInput(void);
void playerInput(void);