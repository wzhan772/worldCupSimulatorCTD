#include <stdio.h>
//include the other files
#include "worldCupDB.h"
#include "worldcup_team.h"
#include "worldcup_player.h"

void teamInput(void)
{
    //user input storage
    char userInput;
    int teamSearch;
    // read in operation code and determine which option to show next
    printf("  Enter team operation code: ");
    scanf("%c", &userInput);
    //if the user wants to insert a team
    if (userInput == 'i') {
        //add the team associated
        addTeam(&headTeam);
    }
    //if the user wants to search for a team
    else if (userInput == 's') {
        printf("  Enter team code to search for: ");
        //get user input
        scanf("%d", &teamSearch);
        //search for team associated with that code
        TeamNode *team = searchTeam(headTeam, teamSearch);
        //if the team does not  exist print error; otherwise print the team
        if (!team) {
            printf("the team associated with this code does not exist\n");
        }
        else {
            printTeam(team);
        }
    }
    //if the user wants to update a team
    else if (userInput == 'u')
    {
        printf("  Enter desired team code to update: ");
        //get user input
        scanf("%d", &teamSearch);
        //update team associated with that code
        updateTeam(headTeam, teamSearch);
    }
    //if the user wants to print out all the teams
    else if (userInput == 'p')
    {
        //print out all teams
        printTeams(headTeam);
    }
    //if the user wants to delete a team
    else if (userInput == 'd')
    {
        printf("  Enter the code of the team that you would like to be deleted: ");
        //get user input
        scanf("%d", &teamSearch);
        //delete the team associated with that code
        deleteTeam(&headTeam, teamSearch);
    } else {
        printf("Re-enter a valid code or enter command h for help options\n");
    }
}

void playerInput(void) {
    //user input storage
    int playerSearch;
    char userInput;
    printf("  Enter player operation code: ");
    scanf("%c", &userInput);
    //if the user wants to add a player
    if (userInput == 'i') {
        //add player
        addPlayer(&playerTeam);
    //if the user wants to search for a player
    } else if (userInput == 's') {
        printf("  Please enter the player's code: ");
        //get user input
        scanf("%d", &playerSearch);
        //search for the player associated with that code
        PlayerNode *player = searchPlayer(playerTeam, playerSearch);
        //if the player is found print it out but if not give exception
        if (!player) {
            printf("Player does not exist in database.\n");
        } else {
            printPlayer(player);
        }
    //if the user wants to update a player
    } else if (userInput == 'u') {
        printf("  Please enter the player's code: ");
        //get user input
        scanf("%d", &playerSearch);
        //update player
        updatePlayer(playerTeam, playerSearch);
    //if the user wants to print all players
    } else if (userInput == 'p') {
        //print players
        printPlayers(playerTeam);
    //if the user wants to delete a player
    } else if (userInput == 'd') {
        printf("  Enter the code of the player that you would like to be removed: ");
        //get user input
        scanf("%d", &playerSearch);
        //delete the player associated with that code
        deletePlayer(&playerTeam, playerSearch);
    } else {
        printf("Re-enter a valid code or enter command h for help options\n");
    }
}

int main(void)
{
    //welcome message
    printf("****************************************\n");
    printf("*           2211 World cup             *\n");
    printf("****************************************\n");
    //while the user does not enter q to quit
    char userInput;
    while (userInput != 'q') {
        //ask for user input
        printf("Enter desired operation code: ");
        scanf("\n%c", &userInput);
        //clear previous input
        fflush(stdin);
        if (userInput == 't') {
            //team commands
            teamInput();
        }
        else if (userInput == 'p') {
            //player commands
            playerInput();
        }
        else if (userInput == 'h') {
            //help commands
            printf("  All Commands:\n");
            printf("  't' - modify teams. Enter 'p' to modify players in database\n");
            printf("  'i' - insert a team or player into database\n");
            printf("  's' - search for a team or player in database\n");
            printf("  'u' - update a team or player in database\n");
            printf("  'p' - print all teams or players in database\n");
            printf("  'd' - delete a team or player from database\n");
            printf("  'q' - exit the program (no information saved)\n");
        }
        else {
            //invalid input
            printf("Re-enter a valid code or enter command h for help options\n");
        }
        printf("\n");
    }
    return 0;
}


