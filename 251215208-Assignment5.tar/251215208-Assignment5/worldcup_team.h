//declare structure
#define MAX_NAME 25
struct TeamNode {
    int code;
    char name[MAX_NAME];
    char seed[2];
    char kitColor;
    struct TeamNode *nextNode;
};
//set void methods
#define TeamNode struct TeamNode
void addTeam(TeamNode **head);
TeamNode *searchTeam(TeamNode *head, int code);
void updateTeam(TeamNode *head, int code);
void printTeams(TeamNode *head);
void printTeam(TeamNode *head);
void deleteTeam(TeamNode **head, int code);